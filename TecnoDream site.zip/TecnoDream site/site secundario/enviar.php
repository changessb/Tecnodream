<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>TecnoDream</title>
<link rel="icon" href="Imagens/global.ico">
<title>Envio de Formulário</title>
 <meta http-equiv="refresh" content=3;url="http://www.tecnodream.com.br">
 <meta name='viewport' content='width=device-width, initial-scale=1'>
<script src='https://kit.fontawesome.com/a076d05399.js'></script>

  <style>
    body{
    background-color: black;
    }
   p, h1{
      color: white;
       text-align: center;
      
    }
    
    </style>
</head>

<body>

<?php
  $Nome     = $_POST['Nome'];
  $Email    = $_POST['Email'];
  $Telefone    = $_POST['Telefone'];
  $Mensagem = $_POST['Mensagem'];
  
  $corpo  = "Nome: ".$Nome."<BR>\n";
  $corpo .= "Email: ".$Email."<BR>\n";
  $corpo .= "Telefone: ".$Telefone."<BR>\n";
  $corpo .= "Mensagem: ".$Mensagem."<BR>\n";
    
    
    echo("O site será redimencionado em 02 seg.");
  if(mail("tecnodream@tecnodream.com.br","CONTADO pelo SITE",$corpo)){
    echo("<p><i class='fas fa-grin' style='font-size:100px;color:blue'></i> </p>");
    echo("<h1> E-mail enviado com sucesso!</h1>");
  } else {
     echo("<p><i class='fas fa-frown-open' style='font-size:100px;color:white'></i></p>");
    echo("<h1>Erro ao enviar e-mail</h1>");
  }
?>

</body>
</html>